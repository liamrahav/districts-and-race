This directory contains the 0-level adminstrative border of South Africa as a
shapefile.

The file is used by dggridR for demonstrating how a shapefile can be used to
produce a grid which overlays, for example, a country, or any other geolocated
polygon.

The file was drawn from freely available data at:

    http://www.diva-gis.org/gdata

I have used "http://www.mapshaper.org/" to simplify the shapefile in order to
reduce the file size.

TODO
#ifndef _csv_hpp_
#define _csv_hpp_

#include "geom.hpp"
#include <string>

namespace complib {
  std::string OutScoreCSV(const GeoCollection &gc, std::string id);
}

#endif

#ifndef _compactnesslib_hpp_
#define _compactnesslib_hpp_

#include "unbounded_scores.hpp"
#include "bounded_scores.hpp"
#include "geojson.hpp"
#include "geom.hpp"
#include "shapefile.hpp"
#include "csv.hpp"
#include "wkt.hpp"
#include "neighbours.hpp"
#include "SpIndex.hpp"

#endif
